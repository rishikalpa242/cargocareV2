import type { LoaderFunctionArgs, ActionFunctionArgs, MetaFunction } from "react-router"
import { useLoaderData, redirect, useActionData } from "react-router"
import { requireAuth } from "~/lib/auth.server"
import { prisma } from "~/lib/prisma.server"
import { AdminLayout } from "~/components/AdminLayout"
import { LinerBookingForm } from "~/components/LinerBookingForm"
import fs from "fs/promises" // Add this line
import path from "path" // Add this line

export const meta: MetaFunction = () => {
  return [{ title: "Edit Liner Booking - Cargo Care" }, { name: "description", content: "Edit liner booking details" }]
}

export async function loader({ request, params }: LoaderFunctionArgs) {
  try {
    const user = await requireAuth(request)

    // Only allow LINER_BOOKING_TEAM and ADMIN
    if (user.role.name !== "LINER_BOOKING_TEAM" && user.role.name !== "ADMIN" && user.role.name !== "MD") {
      return redirect("/dashboard")
    }

    const { id } = params
    if (!id) {
      throw new Response("Liner booking ID is required", { status: 400 })
    }

    const linerBooking = await prisma.linerBooking.findUnique({
      where: { id },
      include: {
        user: true,
        shipmentPlan: {
          include: {
            user: {
              select: {
                id: true,
                name: true,
                email: true,
              },
            },
          },
        },
      },
    })

    if (!linerBooking) {
      throw new Response("Liner booking not found", { status: 404 })
    }

    // Fetch available shipment plans for linking (only those without existing liner bookings)
    const [availableShipmentPlans, carriers, vessels, organizations] = await Promise.all([
      prisma.shipmentPlan.findMany({
        where: {
          linkedStatus: 0, // Only unlinked plans
        },
        select: {
          id: true,
          data: true,
          createdAt: true,
        },
        orderBy: { createdAt: "desc" },
      }),
      prisma.carrier.findMany({ orderBy: { name: "asc" } }),
      prisma.vessel.findMany({ orderBy: { name: "asc" } }),
      prisma.organization.findMany({ orderBy: { name: "asc" } }),
    ])

    return {
      user,
      linerBooking,
      availableShipmentPlans,
      dataPoints: {
        carriers,
        vessels,
        organizations,
      },
    }
  } catch (error) {
    console.error("Error loading liner booking:", error)
    if (error instanceof Response) {
      throw error
    }
    return redirect("/login")
  }
}

// This function handles saving the uploaded file to your server
async function handleFileUpload(file: FormDataEntryValue | null): Promise<string | null> {
  console.log("handleFileUpload called with:", file) // ADD THIS LINE
  console.log("File type:", typeof file) // ADD THIS LINE

  if (!file || typeof file === "string") {
    console.log("No file or string detected, returning:", typeof file === "string" ? file : null) // ADD THIS LINE
    return typeof file === "string" ? file : null
  }

  const uploadedFile = file as File
  console.log("File name:", uploadedFile.name) // ADD THIS LINE
  console.log("File size:", uploadedFile.size) // ADD THIS LINE

  if (uploadedFile.size === 0) {
    console.log("File size is 0, returning null") // ADD THIS LINE
    return null
  }

  const uploadDir = path.join(process.cwd(), "public", "uploads", "liner-booking-pdfs")
  await fs.mkdir(uploadDir, { recursive: true })

  const uniqueFilename = `${Date.now()}-${uploadedFile.name}`
  const filePath = path.join(uploadDir, uniqueFilename)

  console.log("Saving file to:", filePath) // ADD THIS LINE

  const fileBuffer = Buffer.from(await uploadedFile.arrayBuffer())
  console.log("File buffer size:", fileBuffer.length) // ADD THIS LINE

  await fs.writeFile(filePath, fileBuffer)
  console.log("File saved successfully") // ADD THIS LINE

  return `/uploads/liner-booking-pdfs/${uniqueFilename}`
}

export async function action({ request, params }: ActionFunctionArgs) {
  try {
    const user = await requireAuth(request)

    // Only allow LINER_BOOKING_TEAM and ADMIN
    if (user.role.name !== "LINER_BOOKING_TEAM" && user.role.name !== "ADMIN") {
      return redirect("/dashboard")
    }

    const { id } = params
    if (!id) {
      return Response.json({ error: "Liner booking ID is required" }, { status: 400 })
    }

    const formData = await request.formData()

    // Debug: Log all form data
    console.log("=== FORM DATA DEBUG ===")
    for (const [key, value] of formData.entries()) {
      console.log(`${key}: ${value}`)
    }
    console.log("=== END FORM DATA DEBUG ===")

    // Get basic form values
    const carrier_booking_status = formData.get("current_status") as string // Use current_status from hidden input
    const unmapping_request = formData.get("unmapping_request") === "true" || formData.get("unmapping_request") === "on"
    const request_unmapping = formData.get("request_unmapping") === "true"
    const unmapping_reason = formData.get("unmapping_reason") as string
    const booking_released_to = formData.get("booking_released_to") as string
    const link_to_shipment_plan = formData.get("link_to_shipment_plan") as string

    // Parse liner booking details from form data
    const linerBookingDetails: any[] = []
    let detailIndex = 0
    while (formData.get(`liner_booking_details[${detailIndex}][temporary_booking_number]`) !== null) {
      const etdOriginal = formData.get(
        `liner_booking_details[${detailIndex}][e_t_d_of_original_planned_vessel]`,
      ) as string
      const etdRevised = formData.get(`liner_booking_details[${detailIndex}][etd_of_revised_vessel]`) as string
      const emptyPickupFrom = formData.get(
        `liner_booking_details[${detailIndex}][empty_pickup_validity_from]`,
      ) as string
      const emptyPickupTill = formData.get(
        `liner_booking_details[${detailIndex}][empty_pickup_validity_till]`,
      ) as string
      const gateOpeningDate = formData.get(
        `liner_booking_details[${detailIndex}][estimate_gate_opening_date]`,
      ) as string
      const gateCutoffDate = formData.get(`liner_booking_details[${detailIndex}][estimated_gate_cutoff_date]`) as string
      const siCutoffDate = formData.get(`liner_booking_details[${detailIndex}][s_i_cut_off_date]`) as string
      const bookingReceivedDate = formData.get(
        `liner_booking_details[${detailIndex}][booking_received_from_carrier_on]`,
      ) as string

      linerBookingDetails.push({
        temporary_booking_number: formData.get(
          `liner_booking_details[${detailIndex}][temporary_booking_number]`,
        ) as string,
        suffix_for_anticipatory_temporary_booking_number: formData.get(
          `liner_booking_details[${detailIndex}][suffix_for_anticipatory_temporary_booking_number]`,
        ) as string,
        liner_booking_number: formData.get(`liner_booking_details[${detailIndex}][liner_booking_number]`) as string,
        mbl_number: formData.get(`liner_booking_details[${detailIndex}][mbl_number]`) as string,
        carrier: formData.get(`liner_booking_details[${detailIndex}][carrier]`) as string,
        contract: (formData.get(`liner_booking_details[${detailIndex}][contract]`) as string) || null,
        original_planned_vessel: formData.get(
          `liner_booking_details[${detailIndex}][original-planned_vessel]`,
        ) as string,
        e_t_d_of_original_planned_vessel: etdOriginal ? new Date(etdOriginal).toISOString() : null,
        change_in_original_vessel:
          formData.get(`liner_booking_details[${detailIndex}][change_in_original_vessel]`) === "true",
        revised_vessel: formData.get(`liner_booking_details[${detailIndex}][revised_vessel]`) as string,
        etd_of_revised_vessel: etdRevised ? new Date(etdRevised).toISOString() : null,
        empty_pickup_validity_from: emptyPickupFrom ? new Date(emptyPickupFrom).toISOString() : null,
        empty_pickup_validity_till: emptyPickupTill ? new Date(emptyPickupTill).toISOString() : null,
        estimate_gate_opening_date: gateOpeningDate ? new Date(gateOpeningDate).toISOString() : null,
        estimated_gate_cutoff_date: gateCutoffDate ? new Date(gateCutoffDate).toISOString() : null,
        s_i_cut_off_date: siCutoffDate ? new Date(siCutoffDate).toISOString() : null,
        booking_received_from_carrier_on: bookingReceivedDate ? new Date(bookingReceivedDate).toISOString() : null,
        additional_remarks: formData.get(`liner_booking_details[${detailIndex}][additional_remarks]`) as string,
        line_booking_copy: formData.get(`liner_booking_details[${detailIndex}][line_booking_copy]`) as string,
        line_booking_copy_file: await handleFileUpload(
          formData.get(`liner_booking_details[${detailIndex}][line_booking_copy_file]`),
        ),

        equipment_type: (formData.get(`liner_booking_details[${detailIndex}][equipment_type]`) as string) || "",
        equipment_quantity: (formData.get(`liner_booking_details[${detailIndex}][equipment_quantity]`) as string) || "",
      })
      detailIndex++
    }

    const linerBookingData = {
      carrier_booking_status,
      unmapping_request,
      unmapping_reason,
      booking_released_to,
      liner_booking_details: linerBookingDetails,
    }

    // Check if the "All Booking Assigned" button was clicked
    const allBookingAssigned = formData.get("all_booking_assigned") === "true"

    console.log("All Booking Assigned button clicked:", allBookingAssigned)
    console.log("Request Unmapping button clicked:", request_unmapping)

    if (allBookingAssigned) {
      console.log("Processing 'All Booking Assigned' workflow...")
      // Update both liner booking and shipment plan statuses to "Booked"
      linerBookingData.carrier_booking_status = "Booked"

      // Update the liner booking
      const updatedLinerBooking = await prisma.linerBooking.update({
        where: { id },
        data: {
          data: linerBookingData,
        },
        include: {
          shipmentPlan: true,
        },
      })

      console.log("Liner booking updated. Has shipment plan:", !!updatedLinerBooking.shipmentPlan)

      // Clean up orphaned "Ready for Re-linking" entries that match this booking's equipment
      const currentData = updatedLinerBooking.data as any
      if (currentData.liner_booking_details && Array.isArray(currentData.liner_booking_details)) {
        // Find all "Ready for Re-linking" entries with matching equipment details
        const orphanedBookings = await prisma.linerBooking.findMany({
          where: {
            shipmentPlanId: null, // Unlinked entries
            id: { not: id }, // Exclude current booking
          },
        })

        // Filter orphaned bookings that have matching equipment details
        const bookingsToDelete = orphanedBookings.filter((orphanedBooking) => {
          const orphanedData = orphanedBooking.data as any
          return (
            orphanedData.carrier_booking_status === "Ready for Re-linking" &&
            orphanedData.liner_booking_details &&
            Array.isArray(orphanedData.liner_booking_details) &&
            orphanedData.liner_booking_details.some((orphanedDetail: any) =>
              currentData.liner_booking_details.some(
                (currentDetail: any) =>
                  orphanedDetail.temporary_booking_number === currentDetail.temporary_booking_number ||
                  orphanedDetail.liner_booking_number === currentDetail.liner_booking_number,
              ),
            )
          )
        })

        if (bookingsToDelete.length > 0) {
          console.log(`Found ${bookingsToDelete.length} orphaned "Ready for Re-linking" entries to delete`)

          await prisma.linerBooking.deleteMany({
            where: {
              id: { in: bookingsToDelete.map((booking) => booking.id) },
            },
          })

          console.log("Orphaned Ready for Re-linking entries deleted successfully")
        }
      }

      // Delete duplicate liner bookings with the same shipmentPlanId
      if (updatedLinerBooking.shipmentPlan) {
        const duplicateLinerBookings = await prisma.linerBooking.findMany({
          where: {
            shipmentPlanId: updatedLinerBooking.shipmentPlan.id,
            id: { not: id }, // Exclude the current liner booking
          },
        })

        if (duplicateLinerBookings.length > 0) {
          console.log(`Found ${duplicateLinerBookings.length} duplicate liner bookings to delete`)

          await prisma.linerBooking.deleteMany({
            where: {
              shipmentPlanId: updatedLinerBooking.shipmentPlan.id,
              id: { not: id }, // Exclude the current liner booking
            },
          })

          console.log("Duplicate liner bookings deleted successfully")
        }
      }

      // Update the linked shipment plan status if it exists
      if (updatedLinerBooking.shipmentPlan) {
        const shipmentPlanData = updatedLinerBooking.shipmentPlan.data as any
        console.log("Original shipment plan status:", shipmentPlanData.booking_status)
        shipmentPlanData.booking_status = "Booked"
        console.log("Setting shipment plan status to:", shipmentPlanData.booking_status)

        const updatedShipmentPlan = await prisma.shipmentPlan.update({
          where: { id: updatedLinerBooking.shipmentPlan.id },
          data: {
            data: shipmentPlanData,
            linkedStatus: 1,
          },
        })

        console.log("Shipment plan updated successfully:", updatedShipmentPlan.id)
      } else {
        console.log("No linked shipment plan found")
      }
    } else {
      // Get current liner booking to check actual status
      const currentLinerBooking = await prisma.linerBooking.findUnique({
        where: { id },
        include: { shipmentPlan: true },
      })

      if (!currentLinerBooking) {
        return Response.json({ error: "Liner booking not found" }, { status: 404 })
      }

      const currentData = currentLinerBooking.data as any
      const currentStatus = currentData?.carrier_booking_status || "Awaiting MD Approval"

      console.log("=== UNMAPPING DEBUG ===")
      console.log("unmapping_request from form:", unmapping_request)
      console.log("request_unmapping from form:", request_unmapping)
      console.log("currentStatus:", currentStatus)
      console.log("unmapping_reason:", unmapping_reason)
      console.log("=== END UNMAPPING DEBUG ===")

      // Check if unmapping was requested via the "Request Unmapping" button
      if (request_unmapping && currentStatus === "Booked") {
        // Validate that unmapping reason is provided
        if (!unmapping_reason || unmapping_reason.trim() === "") {
          return Response.json({ error: "Unmapping reason is required" }, { status: 400 })
        }

        console.log("Unmapping requested via button - updating status from Booked to Unmapping Requested")
        linerBookingData.carrier_booking_status = "Unmapping Requested"

        // Also update the linked shipment plan status to reflect unmapping request
        if (currentLinerBooking.shipmentPlan) {
          const shipmentPlanData = currentLinerBooking.shipmentPlan.data as any
          shipmentPlanData.booking_status = "Unmapping Requested"

          await prisma.shipmentPlan.update({
            where: { id: currentLinerBooking.shipmentPlan.id },
            data: {
              data: shipmentPlanData,
            },
          })
          console.log("Updated shipment plan status to Unmapping Requested")
        }
      } else {
        console.log("No unmapping request or status not Booked - keeping current status:", currentStatus)
        // Keep the current status if no special action
        linerBookingData.carrier_booking_status = currentStatus
      }

      // Check if linking to a new shipment plan
      if (link_to_shipment_plan) {
        console.log("=== LINKING TO SHIPMENT PLAN DEBUG ===")
        console.log("link_to_shipment_plan ID:", link_to_shipment_plan)

        // Get current data and preserve it completely - only update booking status
        const existingData = currentLinerBooking.data as any
        const updatedData = {
          ...existingData, // Keep ALL existing data intact
          carrier_booking_status: "Booked", // Only change the booking status
        }

        console.log("Existing data:", JSON.stringify(existingData, null, 2))
        console.log("Updated data (only status changed):", JSON.stringify(updatedData, null, 2))

        // Update liner booking with preserved data
        const updatedLinerBooking = await prisma.linerBooking.update({
          where: { id },
          data: {
            data: updatedData,
          },
        })
        console.log("Liner booking updated successfully with preserved data")

        // Clean up orphaned "Ready for Re-linking" entries that match this booking's equipment
        if (existingData.liner_booking_details && Array.isArray(existingData.liner_booking_details)) {
          // Find all "Ready for Re-linking" entries with matching equipment details
          const orphanedBookings = await prisma.linerBooking.findMany({
            where: {
              shipmentPlanId: null, // Unlinked entries
              id: { not: id }, // Exclude current booking
            },
          })

          // Filter orphaned bookings that have matching equipment details
          const bookingsToDelete = orphanedBookings.filter((orphanedBooking) => {
            const orphanedData = orphanedBooking.data as any
            return (
              orphanedData.carrier_booking_status === "Ready for Re-linking" &&
              orphanedData.liner_booking_details &&
              Array.isArray(orphanedData.liner_booking_details) &&
              orphanedData.liner_booking_details.some((orphanedDetail: any) =>
                existingData.liner_booking_details.some(
                  (currentDetail: any) =>
                    orphanedDetail.temporary_booking_number === currentDetail.temporary_booking_number ||
                    orphanedDetail.liner_booking_number === currentDetail.liner_booking_number,
                ),
              )
            )
          })

          if (bookingsToDelete.length > 0) {
            console.log(
              `Found ${bookingsToDelete.length} orphaned "Ready for Re-linking" entries to delete during linking`,
            )

            await prisma.linerBooking.deleteMany({
              where: {
                id: { in: bookingsToDelete.map((booking) => booking.id) },
              },
            })

            console.log("Orphaned Ready for Re-linking entries deleted successfully during linking")
          }
        }

        // Update the shipment plan to link back and get current data
        const currentShipmentPlan = await prisma.shipmentPlan.findUnique({
          where: { id: link_to_shipment_plan },
        })

        if (currentShipmentPlan) {
          const shipmentPlanData = currentShipmentPlan.data as any
          shipmentPlanData.booking_status = "Booked"

          await prisma.shipmentPlan.update({
            where: { id: link_to_shipment_plan },
            data: {
              linerBookingId: id,
              linkedStatus: 1,
              data: shipmentPlanData,
            },
          })
          console.log("Shipment plan linked and booking status updated to Booked")
        }

        // Delete duplicate liner bookings with the same shipmentPlanId
        const duplicateLinerBookings = await prisma.linerBooking.findMany({
          where: {
            shipmentPlanId: link_to_shipment_plan,
            id: { not: id }, // Exclude the current liner booking
          },
        })

        if (duplicateLinerBookings.length > 0) {
          console.log(
            `Found ${duplicateLinerBookings.length} duplicate liner bookings to delete for shipment plan ${link_to_shipment_plan}`,
          )

          await prisma.linerBooking.deleteMany({
            where: {
              shipmentPlanId: link_to_shipment_plan,
              id: { not: id }, // Exclude the current liner booking
            },
          })

          console.log("Duplicate liner bookings deleted successfully")
        } else {
          console.log("No duplicate liner bookings found")
        }

        console.log("=== END LINKING DEBUG ===")
      } else {
        // Regular update
        await prisma.linerBooking.update({
          where: { id },
          data: {
            data: linerBookingData,
          },
        })
      }
    }

    return redirect("/liner-bookings")
  } catch (error) {
    console.error("Error updating liner booking:", error)
    return Response.json({ error: "Failed to update liner booking" }, { status: 500 })
  }
}

export default function EditLinerBookingPage() {
  const { user, linerBooking, availableShipmentPlans, dataPoints } = useLoaderData<typeof loader>()
  const actionData = useActionData<typeof action>()

  return (
    <AdminLayout user={user}>
      <LinerBookingForm
        mode="edit"
        linerBooking={linerBooking}
        availableShipmentPlans={availableShipmentPlans}
        dataPoints={dataPoints}
        actionData={actionData}
        user={user}
      />
    </AdminLayout>
  )
}
