// FIXED: Updated equipment details state initialization


// FIXED: Group equipment by type for better visualization - handle empty state


// FIXED: Add equipment detail function - don't add if there are no equipment details yet

